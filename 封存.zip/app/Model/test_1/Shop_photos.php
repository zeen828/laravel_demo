<?php

namespace App\Model\test_1;

use Illuminate\Database\Eloquent\Model;

//php artisan make:model Model/test_1/Shop_photos
class Shop_photos extends Model
{
    //
}
