        <footer class="f-footer">
            <div class="footerLogo">
                <a href="">
                    <img src="/test_1/img/logo.png" alt="LOGO">
                </a>
            </div>
        </footer>
