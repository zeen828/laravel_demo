        <header>
            <h1><span>@yield('header_tag')</span></h1>
            <div class="headerLogo">
                <a href="/test_1/index"><img src="/test_1/img/logo.png" alt="LOGO"></a>
            </div>
        </header>
